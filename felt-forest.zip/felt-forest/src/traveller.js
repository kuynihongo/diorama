import * as THREE from 'three';

/** Reference-inspired felt young man. All dimensions are local, Y-up, facing +Z.
 * Rigid pivots preserve seams and fabric volume under the quiet idle animation.
 */
export function createTraveller({felt,ell,tube,line,cutout,stitch}) {
  const root=new THREE.Group();root.name='Felt traveller · male · age 19';
  root.userData={age:19,referenceStyle:'cream hoodie, dark blue denim, brown swept hair, backpack'};
  const c={skin:'#d6a279',skinLight:'#deb18a',hair:'#543528',hairLight:'#694633',hood:'#d5ceb3',rib:'#c4c1a4',thread:'#e8dfc3',denim:'#36566a',denimEdge:'#59798a',shoe:'#647578',sole:'#d9d3b7',leather:'#93694b'};
  const torso=new THREE.Group();root.add(torso);torso.position.y=2.12;
  function rounded(parent,color,pos,size,r=.1){const shape=new THREE.Shape(),[w,h,d]=size;shape.moveTo(-w/2+r,-h/2);shape.lineTo(w/2-r,-h/2);shape.quadraticCurveTo(w/2,-h/2,w/2,-h/2+r);shape.lineTo(w/2,h/2-r);shape.quadraticCurveTo(w/2,h/2,w/2-r,h/2);shape.lineTo(-w/2+r,h/2);shape.quadraticCurveTo(-w/2,h/2,-w/2,h/2-r);shape.lineTo(-w/2,-h/2+r);shape.quadraticCurveTo(-w/2,-h/2,-w/2+r,-h/2);const g=new THREE.ExtrudeGeometry(shape,{depth:Math.max(.01,d-2*r),bevelEnabled:true,bevelSize:r,bevelThickness:r,bevelSegments:4,steps:1});g.translate(0,0,-(d-2*r)/2);const m=new THREE.Mesh(g,felt(color));m.position.set(...pos);m.castShadow=m.receiveShadow=true;parent.add(m);return m}
  function capsule(parent,color,a,b,r1,r2=r1){const A=new THREE.Vector3(...a),B=new THREE.Vector3(...b),dir=B.clone().sub(A);const g=new THREE.CylinderGeometry(r2,r1,dir.length(),20);const m=new THREE.Mesh(g,felt(color));m.position.copy(A).add(B).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());m.castShadow=m.receiveShadow=true;parent.add(m);ell(parent,color,a,[r1,r1,r1]);ell(parent,color,b,[r2,r2,r2]);return m}
  function ribbing(parent,x,y,z,w,h,count=16){for(let i=0;i<count;i++){const xx=x-w/2+(i+.5)/count*w;line(parent,[xx,y-h/2,z],[xx,y+h/2,z],c.thread,.007)}}
  // Trousers continue into the torso; rolled cuffs, inseams and fly are independent details.
  rounded(root,c.denim,[0,2.02,0],[.77,.4,.43],.08);
  for(const side of [-1,1]){
    const x=side*.235;
    capsule(root,c.denim,[x,.48,.025],[x,1.97,0],.18,.205);
    rounded(root,c.denimEdge,[x,.46,.045],[.37,.2,.41],.035);
    line(root,[x+side*.14,.59,.15],[x+side*.16,1.84,.14],'#80928e',.007);
    line(root,[x-side*.13,.58,.17],[x-side*.13,1.9,.17],'#b5ac83',.005);
    const shoe=new THREE.Group();root.add(shoe);shoe.position.set(x,.14,.14);shoe.rotation.y=side*.1;
    ell(shoe,c.sole,[0,-.035,.08],[.235,.1,.4]);ell(shoe,c.shoe,[0,.085,0],[.215,.19,.32]);ell(shoe,c.sole,[0,.055,.29],[.215,.12,.16]);
    for(let k=0;k<3;k++)tube(shoe,[[-.12,.22-k*.018,.03+k*.065],[0,.25-k*.018,.04+k*.065],[.12,.22-k*.018,.03+k*.065]],'#e9dfbf',.016);
    tube(shoe,[[-.21,.0,.23],[-.23,.0,0],[-.2,.0,-.18],[0,.0,-.27],[.2,.0,-.18],[.23,.0,0],[.21,.0,.23]],'#aa9f81',.008);
  }
  tube(root,[[0,2.1,.225],[.015,1.95,.242],[.015,1.77,.22]],'#a7a78c',.008);
  // Backpack sits behind the chest, joined to the visible straps.
  rounded(torso,c.leather,[0,.71,-.34],[.79,1.08,.37],.13);
  rounded(torso,'#7b593f',[0,.44,-.56],[.59,.39,.12],.07);
  tube(torso,[[-.15,1.23,-.35],[-.12,1.4,-.35],[.12,1.4,-.35],[.15,1.23,-.35]],'#9e7654',.035);
  // Hoodie has a tapered continuous surface instead of a ball-shaped torso.
  const profile=[new THREE.Vector2(.34,0),new THREE.Vector2(.39,.12),new THREE.Vector2(.38,.46),new THREE.Vector2(.37,.9),new THREE.Vector2(.42,1.12),new THREE.Vector2(.31,1.32),new THREE.Vector2(.18,1.4)];
  const body=new THREE.Mesh(new THREE.LatheGeometry(profile,48),felt(c.hood));body.scale.z=.68;body.castShadow=body.receiveShadow=true;torso.add(body);
  rounded(torso,c.rib,[0,.035,.01],[.76,.15,.51],.03);ribbing(torso,0,.035,.28,.7,.1,25);
  // Hoodie pouch and curved stitched hem.
  const pocket=[[-.3,.22],[-.29,.39],[-.21,.47],[-.16,.66],[.16,.66],[.21,.47],[.29,.39],[.3,.22]];
  const pouch=cutout(torso,pocket,'#ccc4a8',.035);pouch.position.z=.263;
  stitch(torso,pocket.map(([x,y])=>[x*.96,y,.385]),'#eee2bf',.075,.006);
  for(const side of [-1,1]){
    tube(torso,[[side*.29,.37,.39],[side*.21,.46,.39],[side*.16,.64,.39]],'#b2aa8c',.01);
    // Shoulder straps overlap the jacket and terminate beneath the arms.
    const pts=[[side*.31,.24,.2],[side*.37,.69,.26],[side*.36,1.16,.24],[side*.29,1.35,.04],[side*.3,1.24,-.33]];
    tube(torso,pts,c.leather,.063);
    tube(torso,pts.map(([x,y,z])=>[x-side*.038,y,z+.042]),'#c39d72',.007);
    tube(torso,pts.map(([x,y,z])=>[x+side*.038,y,z+.042]),'#5f4433',.006);
  }
  // Hood opening wraps the base of the neck; folded lips form a visible V.
  ell(torso,'#b7b39c',[0,1.26,-.045],[.31,.25,.255]);ell(torso,'#9c9982',[0,1.39,.0],[.215,.1,.18]);
  for(const side of [-1,1])tube(torso,[[side*.29,1.37,-.02],[side*.24,1.27,.15],[side*.13,1.18,.25],[0,1.08,.29]],'#e1dac1',.055);
  for(const side of [-1,1]){tube(torso,[[side*.12,1.16,.3],[side*.13,.91,.32],[side*.14,.73,.32]],'#f1e8d0',.012);capsule(torso,'#b8ac8c',[side*.14,.72,.32],[side*.14,.68,.32],.015)}
  capsule(torso,c.skin,[0,1.31,0],[0,1.65,0],.12);
  const head=new THREE.Group();torso.add(head);head.position.set(0,1.82,.01);
  // Slightly tapered jaw and broad temples: youthful soft-toy proportions from the reference.
  const headGeo=new THREE.SphereGeometry(1,48,40);const hp=headGeo.attributes.position;for(let i=0;i<hp.count;i++){let x=hp.getX(i),y=hp.getY(i),z=hp.getZ(i);const jaw=y<-.1?1+(y+.1)*.18:1;hp.setXYZ(i,x*.34*jaw,y*.44,z*.285)}headGeo.computeVertexNormals();const face=new THREE.Mesh(headGeo,felt(c.skin));face.castShadow=face.receiveShadow=true;head.add(face);
  for(const side of [-1,1]){ell(head,c.skin,[side*.335,-.025,.005],[.09,.125,.065]);ell(head,'#bf8c68',[side*.36,-.02,.056],[.035,.065,.015]);ell(head,'#3b3025',[side*.135,.055,.266],[.026,.041,.019]);ell(head,'#f4debb',[side*.135-.006,.068,.282],[.007,.01,.004]);tube(head,[[side*.08,.175,.26],[side*.14,.188,.263],[side*.2,.17,.245]],c.hair,.025)}
  ell(head,'#d3a078',[0,-.05,.279],[.049,.099,.055]);ell(head,'#dbab7c',[0,-.1,.317],[.061,.034,.041]);
  tube(head,[[-.09,-.204,.237],[0,-.231,.263],[.09,-.204,.237]],'#995e43',.014);tube(head,[[-.068,-.215,.249],[0,-.227,.267],[.069,-.215,.249]],'#e0aa87',.006);
  // Tailored perimeter seam under the cheeks, as on a sewn plush face.
  const faceSeam=[];for(let i=0;i<=35;i++){const a=Math.PI*.1+i/35*Math.PI*.8;faceSeam.push([Math.cos(a)*.312,-Math.sin(a)*.407,.12])}for(let i=0;i<faceSeam.length-1;i+=2)line(head,faceSeam[i],faceSeam[i+1],'#bc8b68',.005);
  // Back and sides of hair cover the scalp; asymmetric swept forelock defines the silhouette.
  ell(head,c.hair,[0,.25,-.08],[.355,.29,.265]);for(const side of [-1,1])ell(head,c.hair,[side*.295,.15,-.025],[.066,.21,.19]);
  const fringeOutline=[[-.31,.16],[-.31,.31],[-.23,.43],[-.07,.49],[.18,.5],[.29,.55],[.25,.44],[.37,.34],[.32,.28],[.39,.23],[.28,.19],[.09,.22],[-.13,.34],[-.21,.21],[-.25,.04]];
  const fringe=cutout(head,fringeOutline,c.hairLight,.07);fringe.position.z=.175;
  stitch(head,fringeOutline.map(([x,y])=>[x*.97,y,.33]),'#a27b53',.065,.005);
  for(let k=0;k<3;k++)tube(head,[[-.18+k*.025,.4-k*.04,.334],[-.01+k*.05,.38-k*.05,.36],[.19+k*.035,.27-k*.02,.332]],'#79513a',.01);
  // Shoulder -> elbow -> hand pivots. Small overlaps hide articulation seams.
  const arms=[];
  for(const side of [-1,1]){
    const shoulder=new THREE.Group();torso.add(shoulder);shoulder.position.set(side*.4,1.13,0);shoulder.rotation.z=side*.12;
    capsule(shoulder,c.hood,[0,0,0],[0,-.63,.01],.16,.155);
    const elbow=new THREE.Group();shoulder.add(elbow);elbow.position.set(0,-.63,.01);
    capsule(elbow,c.hood,[0,0,0],[0,-.55,.055],.155,.135);
    rounded(elbow,c.rib,[0,-.58,.055],[.26,.13,.25],.035);ribbing(elbow,0,-.58,.19,.21,.08,9);
    ell(elbow,c.skin,[0,-.8,.066],[.1,.18,.065]);ell(elbow,c.skin,[-side*.075,-.75,.116],[.046,.1,.045]);
    for(let k=0;k<3;k++)line(elbow,[-.048+k*.033,-.85,.123],[-.046+k*.033,-.94,.095],'#b88966',.004);
    tube(shoulder,[[side*.1,-.11,.11],[side*.14,-.35,.13],[side*.12,-.57,.12]],'#e8dec0',.006);
    arms.push({side,shoulder,elbow});
  }
  root.position.set(-2.25,0,2.3);root.rotation.y=.08;
  function update(t){torso.position.y=2.12+Math.sin(t*1.6)*.012;torso.scale.x=1+Math.sin(t*1.6)*.006;head.rotation.y=.08+Math.sin(t*.55)*.09;head.rotation.z=Math.sin(t*.7)*.02;const wave=Math.pow(Math.max(0,Math.sin(t*.42)),4);for(const a of arms){a.shoulder.rotation.z=a.side*(.12+(a.side===-1?wave*.72:0));a.elbow.rotation.z=a.side===-1?-.05-wave*(1.35+Math.sin(t*5)*.16):.07+Math.sin(t*.8)*.025}}
  update(0);return {root,update,head,torso,arms};
}
