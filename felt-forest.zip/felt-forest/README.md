# A little way up — felt forest

Runnable Three.js diorama based on the supplied felt woodland reference: ornate blue balloon, terracotta scallops, embroidered suns, open woven basket, sheep, duck, rooster, stitched layered trees and butterflies. A 19-year-old male felt traveller stands beside the balloon, based on the supplied character reference: swept brown hair, cream hoodie with a stitched pouch and drawstrings, dark blue jeans with rolled cuffs, brown backpack straps, and laced shoes with cream toe caps. He breathes, glances around and occasionally waves.

## Run

Requires Node.js 20.19+ or 22.12+ (Node 24 recommended).

```sh
npm install
npm run dev
```

Open the local address printed in the terminal (usually http://127.0.0.1:5173).

## Build / portable preview

```sh
npm run build
npm run preview
```

The included `dist/` folder is already built. It contains all required browser assets and needs no external CDN, fonts, textures or API keys. To serve it without Node:

```sh
python3 -m http.server 8080 --directory dist
```

Open http://localhost:8080. Serve over HTTP; opening index.html directly with file:// is not supported by browser module security.

## Controls

- Drag: orbit the diorama within a frontal viewing arc.
- Scroll / pinch: zoom.
- Pause / Play: freeze or resume the entire scene, including camera drift.
- Drift camera: toggle the slow cinematic camera movement. Dragging disables drift.
- Reset view: return to the original composition.
- Save image: download a PNG of the rendered scene, without interface text.
- The initial motion state respects the operating system's reduced-motion preference.

## How it is built

Hybrid 2.5D / 3D: layered, beveled felt cutouts for trees and bushes; full 3D balloon, basket, characters and embroidery. All assets are generated locally in code, including seeded canvas fiber maps, surface fiber strands, geometry ribs, thread seams, suns, curls, scalloped fabric and basket weave. No paid services or model downloads.

`src/traveller.js` is a separate reusable character factory with parented shoulder, elbow, head and torso pivots. The back of the backpack is inferred from the frontal reference.

`src/main.js` contains the scene, materials, construction helpers, character rigs and animation loop. `src/style.css` contains the responsive preview interface. The random seed makes the scene repeatable. `window.diorama` exposes read-only scene state and `seek(seconds)` / `pause()` for future capture tooling.

## Scope

This is an interpretive prototype, not a pixel-perfect recreation or an imported sculpted asset pack. The reference's lettering is deliberately omitted. Characters are recognizable procedural soft-toy forms; the fabric shading approximates felt rather than simulating individual wool fibers physically. Future close-up production could replace the character rigs with sculpted GLB assets and scanned textile maps. The frontal viewing limits preserve the layered diorama illusion.

Verified: production build, live WebGL render, pause/play, camera toggle, and image export. Three.js is bundled locally. No network calls are made by the built scene.
